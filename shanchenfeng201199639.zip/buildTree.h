#ifndef buildTree_h
#define buildTree_h
extern Node *makeNode( double x, double y, int level );
extern void makeChildren( Node *parent );
#endif
