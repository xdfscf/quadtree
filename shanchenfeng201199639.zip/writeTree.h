#ifndef writeTree_h
#define writeTree_h
extern void writeTree( Node *head );
extern void writeNode( FILE *fp, Node *node );
extern void printOut( FILE *fp, Node *node );
#endif
